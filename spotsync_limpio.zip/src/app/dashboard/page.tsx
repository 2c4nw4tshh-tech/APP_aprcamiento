"use client";
import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useAppStore } from "@/store";
import { NearbySpot } from "@/types";
import { BottomNav } from "@/components/ui/BottomNav";
import { AuthGuard } from "@/components/ui/AuthGuard";
import { SpotDetailModal } from "@/components/modals/SpotDetailModal";
import { Button } from "@/components/ui/Button";
import { RefreshCw } from "lucide-react";

const SpotMap = dynamic(
  () => import("@/components/map/SpotMap"),
  {
    ssr: false,
    loading: () => (
      <div className="fixed inset-0 flex items-center justify-center bg-bg">
        <div className="w-10 h-10 rounded-full border-2 border-accent border-t-transparent animate-spin" />
      </div>
    ),
  }
);

export default function DashboardPage() {
  const { coords, request: getLocation } = useGeolocation();
  const { nearbySpots, setNearbySpots, userLocation } = useAppStore();
  const [selected, setSelected] = useState<NearbySpot | null>(null);
  const [loading, setLoading]   = useState(false);

  useEffect(() => { getLocation(); }, []); // eslint-disable-line

  const fetchSpots = async () => {
    if (!userLocation) return;
    setLoading(true);
    try {
      const res  = await fetch(`/api/spots/nearby?lat=${userLocation.lat}&lng=${userLocation.lng}&radius=600`);
      const json = await res.json();
      if (json.data) setNearbySpots(json.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSpots(); }, [userLocation]); // eslint-disable-line

  const handleOccupied = (id: string) =>
    setNearbySpots(nearbySpots.filter((s) => s.id !== id));

  return (
    <AuthGuard>
      <div style={{ position: "fixed", inset: 0, background: "var(--bg)" }}>

        <div style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
          {coords ? (
            <SpotMap
              center={[coords.lat, coords.lng]}
              spots={nearbySpots}
              onSpotClick={setSelected}
            />
          ) : (
            <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
              <p style={{ color: "var(--muted)", fontSize: 14 }}>Activa la ubicación para ver aparcamientos</p>
              <Button onClick={getLocation} size="sm">Permitir ubicación</Button>
            </div>
          )}
        </div>

        {/* HUD superior */}
        <div style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 1000, padding: "12px 16px", pointerEvents: "none" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{
              fontFamily: "var(--font-grotesk, sans-serif)",
              fontWeight: 700,
              fontSize: 20,
              background: "var(--surface)",
              border: "1px solid var(--border)",
              borderRadius: 999,
              padding: "6px 14px",
              pointerEvents: "auto",
            }}>
              Spot<span style={{ color: "var(--accent)" }}>Sync</span>
            </span>
            <div style={{ display: "flex", gap: 8, pointerEvents: "auto" }}>
              <button
                onClick={fetchSpots}
                style={{
                  background: "var(--surface)",
                  border: "1px solid var(--border)",
                  borderRadius: "50%",
                  width: 40, height: 40,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  cursor: "pointer",
                }}
              >
                <RefreshCw size={16} style={{ color: loading ? "var(--accent)" : "var(--muted)", animation: loading ? "spin 1s linear infinite" : "none" }} />
              </button>
              <span style={{
                background: "var(--surface)",
                border: "1px solid var(--border)",
                borderRadius: 999,
                padding: "6px 12px",
                fontSize: 12,
                fontWeight: 600,
                color: "var(--accent)",
              }}>
                {nearbySpots.length} disponibles
              </span>
            </div>
          </div>
        </div>

        {/* Leyenda */}
        <div style={{
          position: "fixed", bottom: 80, left: 16, zIndex: 1000,
          background: "var(--surface)", border: "1px solid var(--border)",
          borderRadius: 16, padding: "8px 12px",
          display: "flex", flexDirection: "column", gap: 6,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
            <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#22C55E", display: "inline-block" }} />
            Disponible
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
            <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FACC15", display: "inline-block" }} />
            Sale pronto
          </div>
        </div>

        {selected && (
          <SpotDetailModal
            spot={selected}
            onClose={() => setSelected(null)}
            onOccupied={handleOccupied}
          />
        )}

        <BottomNav />
      </div>
    </AuthGuard>
  );
}