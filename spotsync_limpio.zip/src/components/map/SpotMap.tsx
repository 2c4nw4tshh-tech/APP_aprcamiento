"use client";

import Map, { Marker, NavigationControl } from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { MapPin } from "lucide-react";
import { useTheme } from "next-themes";

interface SpotMapProps {
  center?: [number, number]; // [latitud, longitud]
  spots?: any[];
  onSpotClick?: (spot: any) => void; // ← renombrado para consistencia con dashboard
}

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN ?? "";

export default function SpotMap({
  center = [40.416775, -3.70379], // Madrid por defecto
  spots = [],
  onSpotClick,
}: SpotMapProps) {
  const { resolvedTheme } = useTheme();
  const mapStyle =
    resolvedTheme === "dark"
      ? "mapbox://styles/mapbox/dark-v11"
      : "mapbox://styles/mapbox/light-v11";

  return (
    <div className="w-full h-full min-h-[350px] rounded-2xl overflow-hidden relative z-0 border border-base">
      <Map
        mapboxAccessToken={MAPBOX_TOKEN}
        initialViewState={{
          latitude: center[0],
          longitude: center[1],
          zoom: 15,
        }}
        style={{ width: "100%", height: "100%" }}
        mapStyle={mapStyle}
      >
        <NavigationControl position="bottom-right" />

        {/* Marcador posición del usuario */}
        <Marker latitude={center[0]} longitude={center[1]}>
          <div className="relative flex items-center justify-center">
            <div className="w-5 h-5 bg-accent rounded-full border-2 border-white shadow-lg animate-pulse" />
            <div className="absolute w-10 h-10 bg-accent/30 rounded-full animate-ping" />
          </div>
        </Marker>

        {/* Marcadores de spots disponibles */}
        {spots.map((spot) => (
          <Marker
            key={spot.id}
            latitude={spot.latitude}
            longitude={spot.longitude}
            onClick={() => onSpotClick?.(spot)}
          >
            <div className="cursor-pointer bg-surface border-2 border-accent p-2 rounded-full shadow-xl hover:scale-110 transition-transform">
              <MapPin className="text-accent" size={20} />
            </div>
          </Marker>
        ))}
      </Map>
    </div>
  );
}